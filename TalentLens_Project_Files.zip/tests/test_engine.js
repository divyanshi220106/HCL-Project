/* Tests for js/engine.js. Run: node tests/test_engine.js */
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const engine = require("../js/engine.js");

const read = (f) => fs.readFileSync(path.join(__dirname, "..", "data", f), "utf8");
const jd = read("sample_job_description.txt");
const resumes = engine.parseResumes(read("sample_resumes.txt"));
const WEIGHTS = [50, 25, 15, 10];

const tests = {
  "java is not javascript"() {
    assert.deepStrictEqual(engine.skills("Expert in JavaScript"), ["javascript"]);
  },
  "years and education are detected"() {
    assert.strictEqual(engine.yrs("2 years at A and 6 years at B"), 6);
    assert.strictEqual(engine.edu("PhD in physics"), 3);
    assert.strictEqual(engine.edu("It would be nice to be part of the team"), 0);
  },
  "five resumes are parsed with names"() {
    assert.deepStrictEqual(resumes.map((r) => r.name),
      ["Aarav Sharma", "Priya Verma", "Rohan Gupta", "Neha Singh", "Karan Mehta"]);
  },
  "sample ranking matches the Python engine"() {
    const { res, rj } = engine.screenCandidates(jd, resumes, WEIGHTS);
    assert.strictEqual(rj.length, 11);
    assert.deepStrictEqual(res.map((r) => [r.name, r.score]), [
      ["Neha Singh", 84], ["Aarav Sharma", 82], ["Priya Verma", 70],
      ["Karan Mehta", 37], ["Rohan Gupta", 34]]);
  },
  "weights can be changed"() {
    const { res } = engine.screenCandidates(jd, resumes, [0, 0, 100, 0]);
    assert.strictEqual(res.find((r) => r.name === "Priya Verma").score, 67);
  },
};

let passed = 0;
for (const [name, fn] of Object.entries(tests)) {
  fn();
  passed++;
  console.log("PASS", name);
}
console.log(`${passed} of ${passed} tests passed`);
