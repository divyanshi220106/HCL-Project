"""TalentLens - AI-based resume screening engine (Python version of the web app logic)."""
import argparse
import math
import os
import re

# Skill dictionary: canonical skill -> accepted spellings
SKILLS = {
    "python": ["python"], "machine learning": ["machine learning", "ml"],
    "deep learning": ["deep learning"], "tensorflow": ["tensorflow"],
    "pytorch": ["pytorch"], "sql": ["sql", "mysql", "postgresql"],
    "nlp": ["nlp", "natural language processing"],
    "scikit-learn": ["scikit-learn", "sklearn"], "pandas": ["pandas"],
    "numpy": ["numpy"], "java": ["java"], "javascript": ["javascript", "js"],
    "react": ["react", "reactjs"], "node.js": ["node.js", "nodejs"],
    "html": ["html"], "css": ["css"], "django": ["django"], "flask": ["flask"],
    "aws": ["aws", "amazon web services"], "docker": ["docker"],
    "kubernetes": ["kubernetes", "k8s"], "git": ["git", "github"],
    "data analysis": ["data analysis", "data analytics"], "tableau": ["tableau"],
    "power bi": ["power bi"], "excel": ["excel"], "c++": ["c++"],
    "mongodb": ["mongodb"], "rest api": ["rest api", "rest apis", "restful"],
    "agile": ["agile", "scrum"], "communication": ["communication"],
    "leadership": ["leadership", "team lead"],
}
PATTERNS = {
    skill: re.compile(r"(^|[^a-z0-9+#])(" + "|".join(re.escape(a) for a in names) + r")(?![a-z0-9+#])", re.I)
    for skill, names in SKILLS.items()
}
STOP = set("""the and for with are was were has have had that this from you your our will can able
use using used all any not but who its their they them his her she him into over such per also etc
plus new more than then well work working experience years year strong good need needs looking""".split())
EDU_LABELS = ["Not stated", "Bachelor's", "Master's", "PhD"]
WEIGHTS = {"skills": 50, "relevance": 25, "experience": 15, "education": 10}


def extract_skills(text):
    return [s for s, rx in PATTERNS.items() if rx.search(text)]


def extract_years(text):
    found = [int(n) for n in re.findall(r"(\d{1,2})\s*\+?\s*(?:years?|yrs?)", text, re.I)]
    return min(30, max(found, default=0))


def education_level(text):
    if re.search(r"\b(ph\.?d|doctorate)\b", text, re.I): return 3
    if re.search(r"\b(m\.?tech|m\.?sc|masters?|mba|mca)\b", text, re.I): return 2
    if re.search(r"\b(b\.?tech|b\.?sc|bachelors?|bca|b\.?com|bba)\b", text, re.I): return 1
    return 0


def tokens(text):
    words = (w.rstrip(".") for w in re.findall(r"[a-z][a-z+#.]+", text.lower()))
    return [w for w in words if len(w) > 1 and w not in STOP]


def cosine_similarities(job, resumes):
    """TF-IDF vectors for the job + resumes; returns cosine(job, resume) for each resume."""
    docs = [tokens(t) for t in [job] + resumes]
    n = len(docs)
    df = {}
    for d in docs:
        for w in set(d):
            df[w] = df.get(w, 0) + 1
    def vector(d):
        tf = {}
        for w in d:
            tf[w] = tf.get(w, 0) + 1
        return {w: c * (math.log((n + 1) / (df[w] + 1)) + 1) for w, c in tf.items()}
    vecs = [vector(d) for d in docs]
    dot = lambda a, b: sum(v * b[w] for w, v in a.items() if w in b)
    norm = lambda a: math.sqrt(dot(a, a)) or 1
    return [dot(vecs[0], v) / (norm(vecs[0]) * norm(v)) for v in vecs[1:]]


def screen(job, resumes, weights=WEIGHTS, cutoff=60):
    required = extract_skills(job)
    req_years, req_edu = extract_years(job), education_level(job)
    sims = cosine_similarities(job, [r["text"] for r in resumes])
    total = sum(weights.values()) or 1
    results = []
    for r, sim in zip(resumes, sims):
        have = extract_skills(r["text"])
        matched = [s for s in required if s in have]
        years, edu = extract_years(r["text"]), education_level(r["text"])
        parts = {
            "skills": len(matched) / len(required) if required else 0,
            "relevance": min(1, sim / 0.45),
            "experience": min(1, years / req_years) if req_years else min(1, years / 5),
            "education": min(1, edu / req_edu) if req_edu else edu / 3,
        }
        score = round(100 * sum(parts[k] * weights[k] for k in parts) / total)
        status = "Shortlisted" if score >= cutoff else "Under review" if score >= cutoff - 15 else "Not selected"
        results.append({"name": r["name"], "score": score, "status": status, "years": years,
                        "education": EDU_LABELS[edu], "similarity": sim, "parts": parts,
                        "matched": matched, "missing": [s for s in required if s not in have]})
    return sorted(results, key=lambda x: -x["score"])


def load_resumes(path):
    """Read a text file in which resumes are separated by a line containing ---."""
    with open(path, encoding="utf-8") as f:
        blocks = [b.strip() for b in re.split(r"^\s*-{3,}\s*$", f.read(), flags=re.M) if b.strip()]
    # Like the web app, the first line is the candidate name and the full block is analysed.
    return [{"name": b.splitlines()[0].strip(), "text": b} for b in blocks]


def main():
    data = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data")
    parser = argparse.ArgumentParser(description="Rank resumes against a job description.")
    parser.add_argument("--job", default=os.path.join(data, "sample_job_description.txt"))
    parser.add_argument("--resumes", default=os.path.join(data, "sample_resumes.txt"))
    parser.add_argument("--cutoff", type=int, default=60, help="shortlist cutoff score")
    args = parser.parse_args()

    with open(args.job, encoding="utf-8") as f:
        job = f.read()
    ranking = screen(job, load_resumes(args.resumes), cutoff=args.cutoff)

    print(f"{'Rank':<5}{'Candidate':<16}{'Score':>6}  {'Status':<13}Missing skills")
    for rank, c in enumerate(ranking, 1):
        print(f"{rank:<5}{c['name']:<16}{c['score']:>5}%  {c['status']:<13}{', '.join(c['missing']) or '-'}")


if __name__ == "__main__":
    main()
